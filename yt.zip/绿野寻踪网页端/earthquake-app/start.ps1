# 地震速报系统 — 桌面启动器
# 双击运行此脚本即可启动

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir

# 首次运行自动安装依赖
if (-not (Test-Path "node_modules\electron")) {
    Write-Host ""
    Write-Host "================================================" -ForegroundColor Cyan
    Write-Host "  首次运行 — 正在安装 Electron 桌面框架..." -ForegroundColor Yellow
    Write-Host "  请稍候，仅需一次。" -ForegroundColor Yellow
    Write-Host "================================================" -ForegroundColor Cyan
    Write-Host ""
    npm install
    if ($LASTEXITCODE -ne 0) {
        Write-Host "安装失败，请检查网络连接" -ForegroundColor Red
        Read-Host "按回车退出"
        exit 1
    }
}

Write-Host ""
Write-Host "================================================" -ForegroundColor Green
Write-Host "  全球地震速报系统 v3.0 — 正在启动..." -ForegroundColor Green
Write-Host "================================================" -ForegroundColor Green
Write-Host ""

npx electron .
