// 地震速报系统 — Electron 桌面客户端
const { app, BrowserWindow, Menu, dialog } = require('electron');
const path = require('path');

let mainWindow = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    title: '全球地震速报系统',
    icon: path.join(__dirname, 'icon.ico'),
    backgroundColor: '#08100c',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      webSecurity: true
    },
    autoHideMenuBar: true,
    frame: true,
    show: false
  });

  // 移除默认菜单栏
  Menu.setApplicationMenu(null);

  // 加载 HTML
  mainWindow.loadFile(path.join(__dirname, 'earthquake-ticker.html'));

  // 窗口准备好后再显示，避免白屏闪烁
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  // 窗口标题跟随页面标题（启动画面中设置）
  mainWindow.on('page-title-updated', (e) => {
    e.preventDefault();
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});
