@echo off
title 地震速报系统
cd /d "%~dp0"
echo.
echo ╔═══════════════════════════════════════════╗
echo ║       全球地震速报系统 v3.0              ║
echo ║       Earthquake Ticker Desktop          ║
echo ╚═══════════════════════════════════════════╝
echo.
echo 正在启动...
echo.

REM 首次运行自动安装依赖
if not exist "node_modules\electron" (
    echo [首次运行] 正在安装 Electron，请稍候...
    call npm install
    echo.
)

npx electron .
pause
